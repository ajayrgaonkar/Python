myList=["apple","banana","cherry"]




#print(type(myList))
print(len(myList))
print(myList)
list1=["abc",34,48,"male",True]
print(list1)
