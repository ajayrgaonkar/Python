'''
thisList=["apple","banana","cherry"]
print(thisList[0])
print(thisList[1])

print(thisList[2])
print(thisList[-1])
'''
#Range of index
thisList=["apple","banana","cherry","orange","kiwi","melon","mango"]
#print(thisList[2:5])
#print(thisList[:4])
#print(thisList[3:])
#print(thisList[-4:-1])
#print(thisList[-4:])
print(thisList[-4:])