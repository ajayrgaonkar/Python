thisList=list(("apple","banana","cherry"))
print(thisList)