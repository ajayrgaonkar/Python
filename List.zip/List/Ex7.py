thisList=["apple","banana","cherry"]
tropical=["mango","pineapple","papaya"]



thisList.extend(tropical)
print(thisList)