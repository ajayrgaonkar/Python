from traceback import print_list







thisList=["apple","banana","cherry"]  
thisList.clear()
print(thisList)

#thisList.remove("banana")
#print(thisList)
#thisList.pop(1)
#print(thisList)
#thisList.pop()
#print(thisList)
#del thisList[0]
#print(thisList)
#del thisList
#print(thisList)

