thisList=["apple","banana","cherry"]
#thisList.insert(2,"watermalon")
#print(thisList)


#thisList.append("orange")
#print(thisList)
thisList.insert(2,"watermalon")
thisList.append("orange")
print(thisList)