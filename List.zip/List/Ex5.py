thisList=["apple","banana","cherry","orange","kiwi","melon","mango"]




#thisList[2]="blackcurrent"
#print(thisList)

#thisList[1:4]=["a","b","c"]
#print(thisList)
print(thisList)
thisList[1:3]=["watermelon"]
print(thisList)