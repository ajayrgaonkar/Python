thisList=["apple","banana","cherry","orange","kiwi","melon","mango"]




if "kiwit" in thisList:
    print("Yes kiwi is in the fruits list")
else :
        print("Yes kiwi is not in the fruits list")


