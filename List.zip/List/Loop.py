thisList=["apple","banana","cherry"]




#for x in thisList:
 #   print(x)
    
# Looping through the index numbers
'''
for i in range(len(thisList)):
    print(thisList[i])
'''
#while loop 
#i=0
#while i<len(thisList):
 #   print(thisList[i])
 #   i=i+1
 #Looping using List  Comprehension
 #it is shortest syntax for looping
 [print (x) for x in thisList]

