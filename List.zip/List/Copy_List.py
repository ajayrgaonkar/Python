thisList=["Orange","Mango","Kiwi","apple","banana","cherry"]
#newList=thisList.copy()


newList=list(thisList)
print(newList)